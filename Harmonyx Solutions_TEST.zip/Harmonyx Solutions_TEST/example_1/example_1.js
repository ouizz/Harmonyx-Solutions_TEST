const dataSum = (nums, target) => {
    for (let i = 0; i < nums.length; i++) {
        for (let z = i + 1; z < nums.length; z++) {
            if (target == nums[z] + nums[i]) {
                return returnsum = { i, z }
            }
        }
    }
}
let nums = [2,7,11,15]
let target = 9
console.log(dataSum(nums , target))