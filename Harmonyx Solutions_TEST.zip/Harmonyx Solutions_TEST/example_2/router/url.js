const express = require('express')
const router = express.Router()

router.get('/api/return/:moneyprice/:moneyclient' , (req , res) => {
    const { params }    = req;
    const moneyPrice    = params.moneyprice
    const moneyClient   = params.moneyclient
    let money           = (params.moneyclient - params.moneyprice) * 100
    const count         = {}
    let returnMoney     = 0
    let result          = {}
    let i               = 1

    const listBank = {
        '100000'    :  'Bank 1000',
        '50000'     :  'Bank 500',
        '10000'     :  'Bank 100',
        '5000'      :  'Bank 50',
        '2000'      :  'Bank 20',
        '1000'      :  'Coin 10',
        '500'       :  'Coin 5',
        '200'       :  'Coin 2',
        '100'       :  'Coin 1'
    }
    const orderListbank = Object.keys(listBank).reverse()
    
    if(money > 0){
        console.log("ssss");
        for (let key in orderListbank ) {
            returnMoney = money % orderListbank[key];
            const findBank = orderListbank[key] / 100;

            count[findBank] = (money - returnMoney) / orderListbank[key]; 
            money = returnMoney;
            
            if(count[findBank]){ 
                result[i] = (orderListbank[key] / 100) + ' บาท จำนวน ' +count[findBank]
                i++
            }
        }
        res.json({ status: true, data: [result]  });
    }else{
        res.json({ status: false, message: 'Plase insert Bank more than Product Price' });
    }

})

module.exports = router